<p>

Pada program saya, inputan email dan password langsung akan termuat di database saja karena saya hanya memasukkan fungsi koneksi agar terhubung di localhost phpmyadmin. Bahasa pemrograman yang saya gunakan yakni php, html, dan mysql. Namun di dalam program saya tidak terdapat pendeklarasian fungsi terkait validasi email. Jadi, pengguna langsung dapat menginput apapun untuk username atau password. Sedangkan pada codingan dosen, terdapat fungsi validasi email dengan ketentuan / kriteria tertentu. Hal ini tentu lebih memudahkan dan mengamankan akun para pengguna. 

Berdasarkan analisis, saya dapat menyimpulkan bahwa untuk yang lebih ringkas, tentu program Bapak Ardiansyah (Dosen PRPL). Di samping itu, tingkat keamanan pun terjamin. Fungsi pada program juga jelas sehingga mudah dipahami. Sedangkan untuk program saya sendiri, terbilang cukup rumit namun saya masih dapat memahaminya. Program saya juga tidak menjamin keamanan akun pengguna karena tidak mencantumkan fungsi validasi. Jadi bebas-bebas saja. Oleh karena itu, saya akan lebih banyak belajar dan latihan lagi untuk menciptakan program yang sebaik mungkin dimana membuat penggunanya merasa nyaman dan aman.

</p>