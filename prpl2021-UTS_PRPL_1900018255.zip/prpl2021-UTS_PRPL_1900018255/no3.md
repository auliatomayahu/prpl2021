<p>

git config = digunakan untuk mengatur konfigurasi tertentu sesuai keinginan pengguna

git init = digunakan untuk membuat repositori baru

git add = digunakan untuk menambahkan file ke index

git clone = digunakan untuk checkout repositori

git commit = digunakan untuk melakukan commit pada perubahan ke head

git status = digunakan untuk menampilkan daftar file yang berubah bersama dengan file yang ingin di tambahkan atau di-commit

git push = digunakan untuk mengirimkan perubahan ke master branch dari remote repository yang berhubungan dengan direktori kerja 

git checkout = digunakan untuk membuat branch atau untuk berpindah diantaranya

git remote = digunakan untuk membuat user terhubung ke remote repository 

git branch = digunakan untuk me-list, membuat atau menghapus branch

git pull = digunakan untuk menggabungkan semua perubahan yang ada di remote repository ke direktori lokal

git merge = digunakan untuk menggabungkan sebuah branch ke branch aktif

git diff = digunakan untuk menampilkan conflicts

git tag = digunakan untuk menandai commits tertentu

git log = digunakan untuk menampilkan daftar commits yang ada di branch beserta detail-nya

git reset = digunakan untuk me-reset index dan bekerja dengan kondisi commit paling baru

git rm = digunakan untuk menghapus file dari index dan direktori kerja

git stash = digunakan untuk membantu menyimpan perubahan yang tidak langsung di-commit, namun hanya sementara

git show = digunakan untuk menampilkan informasi tentang object pada git

git fetch = digunakan untuk menampilkan semua object dari remote repository yang tidak berada di direktori kerja lokal

git ls-tree = digunakan untuk menampilkan susunan object berdasarkan nama dan mode setiap item, dan nilai blob SHA-1

git cat-file = digunakan untuk menampilkan tipe object 

git prep = digunakan untuk mengizinkan pengguna mencari frase dan/atau kata yang berada di dalam direktori

gitk = digunakan untuk membuat tampilan grafis dari repository lokal yang bisa dipanggil 

git instaweb = digunakan untuk menjalankan web server agar dapat berdampingan dengan repository lokal. 
Nantinya web browser akan langsung diarahkan ke server tersebut

git gc = digunakan untuk mengoptimasi repository melalui garbage collection, yang akan membersihkan file yang tidak dibutuhkan dan mengoptimasinya

git archive = digunakan untuk memungkinkan user membuat file zip atau tar yang mengandung susunan repository

git prune = digunakan untuk membuat object yang tidak memiliki incoming pointers akan dihapus

git fsck = digunakan untuk membuat pengecekan keseluruhan dari file system git

git rebase = digunakan untuk menerapkan ulang commit di branch yang lain

</p>