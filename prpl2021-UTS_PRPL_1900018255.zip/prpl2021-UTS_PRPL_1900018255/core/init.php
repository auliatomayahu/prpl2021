<?php

// untuk menghemat waktu dan memudahkan saat proses include file-file yang akan dibutuhkan
// sehingga tidak perlu mengincludekanya satu persatu lagi ke dalam file tersebut
require_once "config/koneksi.php";
require_once "config/functions.php";
?>
